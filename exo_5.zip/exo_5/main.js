import App from "./App.js";

window.onload = () => {
  new App();
};
